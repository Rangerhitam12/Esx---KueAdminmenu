fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Kue Kering'
description 'Complete Admin Menu for ESX Legacy using ox_lib.contextmenu'
version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@es_extended/imports.lua'
}

server_script 'server/main.lua'
client_script 'client/main.lua'



dependency '/assetpacks'